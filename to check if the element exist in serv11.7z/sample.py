import sqlite3

conn=sqlite3.connect('swerv11.db')



c=conn.cursor()
print("Enter a signal name:")
id_name=input()

c.execute("SELECT A.alias ,A.node  from Aliases as A,Nodes as N where N.id=A.node  AND N.id=? ",(id_name,))

lst=c.fetchall()



if(len(lst)>0):
    for x in lst:
        print(x)

else:
    print("Not Found")


