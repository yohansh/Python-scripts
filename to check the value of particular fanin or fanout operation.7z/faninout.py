import sqlite3

conn=sqlite3.connect('swerv11.db')



c=conn.cursor()
print("Enter a signal name:")
id_name=input()
#swerv_wrapper.swerv.lsu.addr_in_dccm_dc1

print("Operation to be performed(fanin or fanout)")
opr=input()

if(opr!="fanin" and opr!="fanout"):
    raise Exception("Please enter a valid operation")

elif(opr=="fanin"):
    c.execute('''SELECT CB.uid,CB.verilog_code
                 from CodeBlocks as CB
                 where CB.uid=(SELECT G.cblk_id
                 from GenCBLKs as G
                 where G.node=?)''',(id_name,))
                 

    lst=dict(c.fetchall())
    if(len(lst)>0): 
        for x in lst.items():
            print("////////////////////////////////////////////////////////////////////////////////////////")
            print(x)
        
        print("////////////////////////////////////////////////////////////////////////////////////////")

    else:
        print("No fanin is present")         



elif(opr=="fanout"):
    c.execute('''SELECT CB.uid,CB.verilog_code
                from CodeBlocks as CB
                where CB.uid in (SELECT G.cblk_id
                from GenCBLKs as G
                where G.node in (SELECT node
                from Fanouts as Fout
                where fanout=?))''',(id_name,))
                 
    lst=dict(c.fetchall())
    if(len(lst)>0): 
        for x in lst.items():
            print("////////////////////////////////////////////////////////////////////////////////////////")
            print(x)
        print("////////////////////////////////////////////////////////////////////////////////////////")

    else:
        print("No fanout is present")             



