import sqlite3

conn=sqlite3.connect('swerv11.db')



c=conn.cursor()



c.execute("SELECT count(distinct id) from Nodes")



print(c.fetchall())

conn.commit()

