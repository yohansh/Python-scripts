import sqlite3

conn=sqlite3.connect('sim.vcd.sqlite')



c=conn.cursor()

print("Enter a signal name:")
signal_name=input()

print("Enter the time")
t=input()


word=signal_name.rpartition('.')

id_name=word[2]
id_hier=word[0]


c.execute("select code_id from signals where name= ? and hier= ?",(id_name,id_hier))

lst=c.fetchall()

id_code=0

if len(lst)>0:
    id_code=lst[0][0]
    


c.execute("select max(SV.time) ,SV.value from signal_values  as SV where SV.time<=? and SV.code_id=?",(t,id_code))

lst2=c.fetchall()
# print(lst2)
print(lst2[0][1])



